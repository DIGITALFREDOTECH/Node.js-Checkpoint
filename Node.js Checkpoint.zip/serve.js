const http = require("node:http");

// Server has a 5 seconds keep-alive timeout by default
http
  .createServer((req, res) => {
    res.write("<h1>Hello Node!!!!</h1>\n");
    res.end();
  })
  .listen(3000);