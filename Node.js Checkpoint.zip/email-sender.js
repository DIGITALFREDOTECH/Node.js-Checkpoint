var nodemailer = require("nodemailer");

var transporter = nodemailer.createTransport({
  host: "GOmycode.co",
  port: 587,
  secure: false, // Use `true` for port 465, `false` for all other ports
  auth: {
    user: "support@GOmycode.co",
    pass: "gomycode122",
  },
});

var mailOptions = {
  from: "support@GOmycode.co",
  to: ["kkdkk50@gmail.com ","computers0@gmail.com","joseph@gmail.com"],
  subject: "Sending Email using Node.js",
  text: "By fredo!",
  html: "<h1> That was easy By digitalfredo! </h1>",
};

transporter.sendMail(mailOptions, function (error, info) {
  if (error) {
    console.log(error);
  } else {
    console.log("Email sent: " + info.response);
  }
});
