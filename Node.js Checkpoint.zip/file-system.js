const fs = require('node:fs');

const content = 'Hello Node';

fs.writeFileSync('welcome.txt', content, err => {
  if (err) {
    console.error(err);
  } else {
    // file written successfully
  }
});

try {
  const data = fs.readFileSync('welcome.txt', 'utf8');
  console.log(data);
} catch (err) {
  console.error(err);
}